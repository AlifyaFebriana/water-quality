package com.example.halamanloading;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Loading extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);
        loading();
    }

    void loading(){

        new Thread(){
            public void run(){
                try {
                    Thread.sleep(5000);
                }catch (Exception ee) {
                    Intent i = new Intent(Loading.this, MainActivity.class);
                    Loading.this.finish();
                    startActivity(i);
                }
            }}.start();
    }
}